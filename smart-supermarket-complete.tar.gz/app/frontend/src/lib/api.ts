import { createClient } from '@metagptx/web-sdk';
import type {
  Product,
  Customer,
  Employee,
  Shift,
  Supplier,
  PurchaseOrder,
  PurchaseOrderItem,
  Sale,
  SaleItem,
  Receipt,
  Return,
  ReturnItem,
  Account,
  JournalEntry,
  JournalDetail,
  AIAlert,
  SalesForecast,
  ProfitPrediction,
  CashFlowPrediction,
  DailySummary,
  Notification,
  AuditLog,
  TaxRate,
  Location,
  PaymentMethod,
  StockAdjustment,
} from '@/types';

// Create client instance
export const client = createClient();

// API helper functions
export const api = {
  // Products
  products: {
    getAll: async (): Promise<Product[]> => {
      const response = await client.entities.products.query({
        query: {},
        limit: 1000,
      });
      return response.data.items as Product[];
    },
    getLowStock: async (): Promise<Product[]> => {
      const response = await client.entities.products.query({
        query: {},
        limit: 1000,
      });
      return (response.data.items as Product[]).filter((p) => p.quantity <= p.low_stock_threshold);
    },
    getById: async (id: number): Promise<Product> => {
      const response = await client.entities.products.get({
        id: id.toString(),
      });
      return response.data as Product;
    },
    create: async (data: Omit<Product, 'id'>): Promise<Product> => {
      const response = await client.entities.products.create({
        data,
      });
      return response.data as Product;
    },
    update: async (id: number, data: Partial<Product>): Promise<Product> => {
      const response = await client.entities.products.update({
        id: id.toString(),
        data,
      });
      return response.data as Product;
    },
    delete: async (id: number): Promise<void> => {
      await client.entities.products.delete({ id: id.toString() });
    },
  },

  // Customers
  customers: {
    getAll: async (): Promise<Customer[]> => {
      const response = await client.entities.customers.query({
        query: {},
        limit: 1000,
      });
      return response.data.items as Customer[];
    },
    getById: async (id: number): Promise<Customer> => {
      const response = await client.entities.customers.get({
        id: id.toString(),
      });
      return response.data as Customer;
    },
    create: async (data: Omit<Customer, 'id'>): Promise<Customer> => {
      const response = await client.entities.customers.create({
        data,
      });
      return response.data as Customer;
    },
    update: async (id: number, data: Partial<Customer>): Promise<Customer> => {
      const response = await client.entities.customers.update({
        id: id.toString(),
        data,
      });
      return response.data as Customer;
    },
  },

  // Employees
  employees: {
    getAll: async (): Promise<Employee[]> => {
      const response = await client.entities.employees.query({
        query: {},
        limit: 1000,
      });
      return response.data.items as Employee[];
    },
    getById: async (id: number): Promise<Employee> => {
      const response = await client.entities.employees.get({
        id: id.toString(),
      });
      return response.data as Employee;
    },
    create: async (data: Omit<Employee, 'id'>): Promise<Employee> => {
      const response = await client.entities.employees.create({
        data,
      });
      return response.data as Employee;
    },
    update: async (id: number, data: Partial<Employee>): Promise<Employee> => {
      const response = await client.entities.employees.update({
        id: id.toString(),
        data,
      });
      return response.data as Employee;
    },
  },

  // Shifts
  shifts: {
    getAll: async (): Promise<Shift[]> => {
      const response = await client.entities.shifts.query({
        query: {},
        sort: '-shift_date',
        limit: 1000,
      });
      return response.data.items as Shift[];
    },
    create: async (data: Omit<Shift, 'id'>): Promise<Shift> => {
      const response = await client.entities.shifts.create({
        data,
      });
      return response.data as Shift;
    },
    update: async (id: number, data: Partial<Shift>): Promise<Shift> => {
      const response = await client.entities.shifts.update({
        id: id.toString(),
        data,
      });
      return response.data as Shift;
    },
  },

  // Suppliers
  suppliers: {
    getAll: async (): Promise<Supplier[]> => {
      const response = await client.entities.suppliers.query({
        query: {},
        limit: 1000,
      });
      return response.data.items as Supplier[];
    },
    getById: async (id: number): Promise<Supplier> => {
      const response = await client.entities.suppliers.get({
        id: id.toString(),
      });
      return response.data as Supplier;
    },
    create: async (data: Omit<Supplier, 'id'>): Promise<Supplier> => {
      const response = await client.entities.suppliers.create({
        data,
      });
      return response.data as Supplier;
    },
    update: async (id: number, data: Partial<Supplier>): Promise<Supplier> => {
      const response = await client.entities.suppliers.update({
        id: id.toString(),
        data,
      });
      return response.data as Supplier;
    },
  },

  // Purchase Orders
  purchaseOrders: {
    getAll: async (): Promise<PurchaseOrder[]> => {
      const response = await client.entities.purchase_orders.query({
        query: {},
        sort: '-order_date',
        limit: 1000,
      });
      return response.data.items as PurchaseOrder[];
    },
    getById: async (id: number): Promise<PurchaseOrder> => {
      const response = await client.entities.purchase_orders.get({
        id: id.toString(),
      });
      return response.data as PurchaseOrder;
    },
    create: async (data: Omit<PurchaseOrder, 'id'>): Promise<PurchaseOrder> => {
      const response = await client.entities.purchase_orders.create({
        data,
      });
      return response.data as PurchaseOrder;
    },
    update: async (id: number, data: Partial<PurchaseOrder>): Promise<PurchaseOrder> => {
      const response = await client.entities.purchase_orders.update({
        id: id.toString(),
        data,
      });
      return response.data as PurchaseOrder;
    },
  },

  // Purchase Order Items
  purchaseOrderItems: {
    getByPOId: async (poId: number): Promise<PurchaseOrderItem[]> => {
      const response = await client.entities.purchase_order_items.query({
        query: { po_id: poId },
        limit: 1000,
      });
      return response.data.items as PurchaseOrderItem[];
    },
    create: async (data: Omit<PurchaseOrderItem, 'id'>): Promise<PurchaseOrderItem> => {
      const response = await client.entities.purchase_order_items.create({
        data,
      });
      return response.data as PurchaseOrderItem;
    },
  },

  // Stock Adjustments
  stockAdjustments: {
    getAll: async (): Promise<StockAdjustment[]> => {
      const response = await client.entities.stock_adjustments.query({
        query: {},
        sort: '-adjustment_date',
        limit: 1000,
      });
      return response.data.items as StockAdjustment[];
    },
    create: async (data: Omit<StockAdjustment, 'id'>): Promise<StockAdjustment> => {
      const response = await client.entities.stock_adjustments.create({
        data,
      });
      return response.data as StockAdjustment;
    },
  },

  // Sales
  sales: {
    getAll: async (): Promise<Sale[]> => {
      const response = await client.entities.sales.query({
        query: {},
        sort: '-sale_date',
        limit: 1000,
      });
      return response.data.items as Sale[];
    },
    getRecent: async (limit = 10): Promise<Sale[]> => {
      const response = await client.entities.sales.query({
        query: {},
        sort: '-sale_date',
        limit,
      });
      return response.data.items as Sale[];
    },
    create: async (data: Omit<Sale, 'id'>): Promise<Sale> => {
      const response = await client.entities.sales.create({
        data,
      });
      return response.data as Sale;
    },
  },

  // Sale Items
  saleItems: {
    getBySaleId: async (saleId: number): Promise<SaleItem[]> => {
      const response = await client.entities.sale_items.query({
        query: { sale_id: saleId },
        limit: 1000,
      });
      return response.data.items as SaleItem[];
    },
    create: async (data: Omit<SaleItem, 'id'>): Promise<SaleItem> => {
      const response = await client.entities.sale_items.create({
        data,
      });
      return response.data as SaleItem;
    },
  },

  // Receipts
  receipts: {
    getAll: async (): Promise<Receipt[]> => {
      const response = await client.entities.receipts.query({
        query: {},
        sort: '-receipt_date',
        limit: 1000,
      });
      return response.data.items as Receipt[];
    },
    create: async (data: Omit<Receipt, 'id'>): Promise<Receipt> => {
      const response = await client.entities.receipts.create({
        data,
      });
      return response.data as Receipt;
    },
  },

  // Returns
  returns: {
    getAll: async (): Promise<Return[]> => {
      const response = await client.entities.returns.query({
        query: {},
        sort: '-return_date',
        limit: 1000,
      });
      return response.data.items as Return[];
    },
    create: async (data: Omit<Return, 'id'>): Promise<Return> => {
      const response = await client.entities.returns.create({
        data,
      });
      return response.data as Return;
    },
    update: async (id: number, data: Partial<Return>): Promise<Return> => {
      const response = await client.entities.returns.update({
        id: id.toString(),
        data,
      });
      return response.data as Return;
    },
  },

  // Return Items
  returnItems: {
    getByReturnId: async (returnId: number): Promise<ReturnItem[]> => {
      const response = await client.entities.return_items.query({
        query: { return_id: returnId },
        limit: 1000,
      });
      return response.data.items as ReturnItem[];
    },
    create: async (data: Omit<ReturnItem, 'id'>): Promise<ReturnItem> => {
      const response = await client.entities.return_items.create({
        data,
      });
      return response.data as ReturnItem;
    },
  },

  // Accounts
  accounts: {
    getAll: async (): Promise<Account[]> => {
      const response = await client.entities.accounts.query({
        query: {},
        limit: 1000,
      });
      return response.data.items as Account[];
    },
    getByType: async (type: string): Promise<Account[]> => {
      const response = await client.entities.accounts.query({
        query: { account_type: type },
        limit: 1000,
      });
      return response.data.items as Account[];
    },
  },

  // Journal Entries
  journalEntries: {
    getAll: async (): Promise<JournalEntry[]> => {
      const response = await client.entities.journal_entries.query({
        query: {},
        sort: '-entry_date',
        limit: 1000,
      });
      return response.data.items as JournalEntry[];
    },
    create: async (data: Omit<JournalEntry, 'id'>): Promise<JournalEntry> => {
      const response = await client.entities.journal_entries.create({
        data,
      });
      return response.data as JournalEntry;
    },
  },

  // Journal Details
  journalDetails: {
    getByEntryId: async (entryId: number): Promise<JournalDetail[]> => {
      const response = await client.entities.journal_details.query({
        query: { entry_id: entryId },
        limit: 1000,
      });
      return response.data.items as JournalDetail[];
    },
    create: async (data: Omit<JournalDetail, 'id'>): Promise<JournalDetail> => {
      const response = await client.entities.journal_details.create({
        data,
      });
      return response.data as JournalDetail;
    },
  },

  // AI Alerts
  aiAlerts: {
    getRecent: async (limit = 10): Promise<AIAlert[]> => {
      const response = await client.entities.ai_alerts.query({
        query: {},
        sort: '-alert_date',
        limit,
      });
      return response.data.items as AIAlert[];
    },
  },

  // Sales Forecasts
  salesForecasts: {
    getAll: async (): Promise<SalesForecast[]> => {
      const response = await client.entities.sales_forecasts.query({
        query: {},
        sort: 'forecast_date',
        limit: 1000,
      });
      return response.data.items as SalesForecast[];
    },
  },

  // Profit Predictions
  profitPredictions: {
    getAll: async (): Promise<ProfitPrediction[]> => {
      const response = await client.entities.profit_predictions.query({
        query: {},
        sort: 'prediction_date',
        limit: 1000,
      });
      return response.data.items as ProfitPrediction[];
    },
  },

  // Cash Flow Predictions
  cashFlowPredictions: {
    getAll: async (): Promise<CashFlowPrediction[]> => {
      const response = await client.entities.cash_flow_predictions.query({
        query: {},
        sort: 'prediction_date',
        limit: 1000,
      });
      return response.data.items as CashFlowPrediction[];
    },
  },

  // Daily Summaries
  dailySummaries: {
    getRecent: async (limit = 7): Promise<DailySummary[]> => {
      const response = await client.entities.daily_summaries.query({
        query: {},
        sort: '-summary_date',
        limit,
      });
      return response.data.items as DailySummary[];
    },
  },

  // Notifications
  notifications: {
    getAll: async (): Promise<Notification[]> => {
      const response = await client.entities.notifications.query({
        query: {},
        sort: '-created_at',
        limit: 100,
      });
      return response.data.items as Notification[];
    },
    markAsRead: async (id: number): Promise<Notification> => {
      const response = await client.entities.notifications.update({
        id: id.toString(),
        data: { is_read: true },
      });
      return response.data as Notification;
    },
  },

  // Audit Logs
  auditLogs: {
    getRecent: async (limit = 50): Promise<AuditLog[]> => {
      const response = await client.entities.audit_logs.query({
        query: {},
        sort: '-created_at',
        limit,
      });
      return response.data.items as AuditLog[];
    },
    create: async (data: Omit<AuditLog, 'id'>): Promise<AuditLog> => {
      const response = await client.entities.audit_logs.create({
        data,
      });
      return response.data as AuditLog;
    },
  },

  // Tax Rates
  taxRates: {
    getAll: async (): Promise<TaxRate[]> => {
      const response = await client.entities.tax_rates.query({
        query: {},
        limit: 100,
      });
      return response.data.items as TaxRate[];
    },
    getActive: async (): Promise<TaxRate[]> => {
      const response = await client.entities.tax_rates.query({
        query: { is_active: true },
        limit: 100,
      });
      return response.data.items as TaxRate[];
    },
  },

  // Locations
  locations: {
    getAll: async (): Promise<Location[]> => {
      const response = await client.entities.locations.query({
        query: {},
        limit: 100,
      });
      return response.data.items as Location[];
    },
    getActive: async (): Promise<Location[]> => {
      const response = await client.entities.locations.query({
        query: { is_active: true },
        limit: 100,
      });
      return response.data.items as Location[];
    },
  },

  // Payment Methods
  paymentMethods: {
    getAll: async (): Promise<PaymentMethod[]> => {
      const response = await client.entities.payment_methods.query({
        query: {},
        limit: 100,
      });
      return response.data.items as PaymentMethod[];
    },
    getActive: async (): Promise<PaymentMethod[]> => {
      const response = await client.entities.payment_methods.query({
        query: { is_active: true },
        limit: 100,
      });
      return response.data.items as PaymentMethod[];
    },
  },
};