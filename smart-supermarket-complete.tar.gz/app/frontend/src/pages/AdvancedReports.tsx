import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/lib/api';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { FileText, Download, TrendingUp, DollarSign, Package, Users, Calendar, BarChart3 } from 'lucide-react';
import type { Sale, Product, Customer, Employee, PurchaseOrder } from '@/types';

export default function AdvancedReports() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [sales, setSales] = useState<Sale[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [reportType, setReportType] = useState<'sales' | 'inventory' | 'financial' | 'customer' | 'employee'>('sales');
  const [dateRange, setDateRange] = useState<'today' | 'week' | 'month' | 'quarter' | 'year'>('month');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [salesData, productsData, customersData, employeesData, posData] = await Promise.all([
        api.sales.getAll(),
        api.products.getAll(),
        api.customers.getAll(),
        api.employees.getAll(),
        api.purchaseOrders.getAll(),
      ]);
      setSales(salesData);
      setProducts(productsData);
      setCustomers(customersData);
      setEmployees(employeesData);
      setPurchaseOrders(posData);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load report data',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getDateRangeFilter = () => {
    const now = new Date();
    const ranges = {
      today: new Date(now.setHours(0, 0, 0, 0)),
      week: new Date(now.setDate(now.getDate() - 7)),
      month: new Date(now.setMonth(now.getMonth() - 1)),
      quarter: new Date(now.setMonth(now.getMonth() - 3)),
      year: new Date(now.setFullYear(now.getFullYear() - 1)),
    };
    return ranges[dateRange];
  };

  const filterByDateRange = <T extends { sale_date?: string; order_date?: string; created_at?: string }>(items: T[]): T[] => {
    const startDate = getDateRangeFilter();
    return items.filter(item => {
      const itemDate = new Date(item.sale_date || item.order_date || item.created_at || '');
      return itemDate >= startDate;
    });
  };

  const generateSalesReport = () => {
    const filteredSales = filterByDateRange(sales);
    const totalRevenue = filteredSales.reduce((sum, sale) => sum + sale.total_amount, 0);
    const totalTransactions = filteredSales.length;
    const avgTransaction = totalTransactions > 0 ? totalRevenue / totalTransactions : 0;
    
    const salesByPayment = filteredSales.reduce((acc, sale) => {
      acc[sale.payment_method] = (acc[sale.payment_method] || 0) + sale.total_amount;
      return acc;
    }, {} as Record<string, number>);

    const topCustomers = customers
      .map(customer => ({
        ...customer,
        totalSpent: filteredSales
          .filter(s => s.customer_id === customer.id)
          .reduce((sum, s) => sum + s.total_amount, 0),
      }))
      .sort((a, b) => b.totalSpent - a.totalSpent)
      .slice(0, 10);

    return {
      totalRevenue,
      totalTransactions,
      avgTransaction,
      salesByPayment,
      topCustomers,
    };
  };

  const generateInventoryReport = () => {
    const lowStockItems = products.filter(p => p.quantity <= (p.reorder_level || 10));
    const outOfStockItems = products.filter(p => p.quantity === 0);
    const totalInventoryValue = products.reduce((sum, p) => sum + (p.quantity * p.price), 0);
    
    const topSellingProducts = products
      .map(product => ({
        ...product,
        soldQuantity: sales.reduce((sum, sale) => {
          // Assuming we track product sales in sale items
          return sum + (sale.items_count || 0);
        }, 0),
      }))
      .sort((a, b) => b.soldQuantity - a.soldQuantity)
      .slice(0, 10);

    return {
      totalProducts: products.length,
      lowStockItems,
      outOfStockItems,
      totalInventoryValue,
      topSellingProducts,
    };
  };

  const generateFinancialReport = () => {
    const filteredSales = filterByDateRange(sales);
    const filteredPOs = filterByDateRange(purchaseOrders);
    
    const totalRevenue = filteredSales.reduce((sum, sale) => sum + sale.total_amount, 0);
    const totalCOGS = filteredPOs
      .filter(po => po.status === 'Received')
      .reduce((sum, po) => sum + po.total_amount, 0);
    const grossProfit = totalRevenue - totalCOGS;
    const grossMargin = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;
    
    const operatingExpenses = employees.reduce((sum, emp) => sum + (emp.salary || 0), 0);
    const netProfit = grossProfit - operatingExpenses;
    const netMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

    return {
      totalRevenue,
      totalCOGS,
      grossProfit,
      grossMargin,
      operatingExpenses,
      netProfit,
      netMargin,
    };
  };

  const generateCustomerReport = () => {
    const filteredSales = filterByDateRange(sales);
    const activeCustomers = customers.filter(c => c.status === 'Active').length;
    const newCustomers = filterByDateRange(customers).length;
    
    const customersByTier = customers.reduce((acc, customer) => {
      acc[customer.membership_tier] = (acc[customer.membership_tier] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const avgCustomerValue = customers.length > 0
      ? filteredSales.reduce((sum, sale) => sum + sale.total_amount, 0) / customers.length
      : 0;

    const retentionRate = customers.length > 0
      ? (customers.filter(c => {
          const customerSales = sales.filter(s => s.customer_id === c.id);
          return customerSales.length > 1;
        }).length / customers.length) * 100
      : 0;

    return {
      totalCustomers: customers.length,
      activeCustomers,
      newCustomers,
      customersByTier,
      avgCustomerValue,
      retentionRate,
    };
  };

  const generateEmployeeReport = () => {
    const activeEmployees = employees.filter(e => e.status === 'Active').length;
    const onLeave = employees.filter(e => e.status === 'On Leave').length;
    const totalPayroll = employees.reduce((sum, emp) => sum + (emp.salary || 0), 0);
    const avgSalary = employees.length > 0 ? totalPayroll / employees.length : 0;

    const employeesByDepartment = employees.reduce((acc, emp) => {
      const dept = emp.department || 'Unassigned';
      acc[dept] = (acc[dept] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      totalEmployees: employees.length,
      activeEmployees,
      onLeave,
      totalPayroll,
      avgSalary,
      employeesByDepartment,
    };
  };

  const handleExportReport = () => {
    let reportData = '';
    let filename = '';

    switch (reportType) {
      case 'sales': {
        const report = generateSalesReport();
        reportData = JSON.stringify(report, null, 2);
        filename = `sales-report-${dateRange}.json`;
        break;
      }
      case 'inventory': {
        const report = generateInventoryReport();
        reportData = JSON.stringify(report, null, 2);
        filename = `inventory-report-${dateRange}.json`;
        break;
      }
      case 'financial': {
        const report = generateFinancialReport();
        reportData = JSON.stringify(report, null, 2);
        filename = `financial-report-${dateRange}.json`;
        break;
      }
      case 'customer': {
        const report = generateCustomerReport();
        reportData = JSON.stringify(report, null, 2);
        filename = `customer-report-${dateRange}.json`;
        break;
      }
      case 'employee': {
        const report = generateEmployeeReport();
        reportData = JSON.stringify(report, null, 2);
        filename = `employee-report-${dateRange}.json`;
        break;
      }
    }

    const blob = new Blob([reportData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      title: 'Success',
      description: 'Report exported successfully',
    });
  };

  const salesReport = generateSalesReport();
  const inventoryReport = generateInventoryReport();
  const financialReport = generateFinancialReport();
  const customerReport = generateCustomerReport();
  const employeeReport = generateEmployeeReport();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Advanced Reports & Analytics</h1>
          <p className="text-[#A1A1AA] mt-1">Comprehensive business intelligence and insights</p>
        </div>
        <Button
          onClick={handleExportReport}
          disabled={isLoading}
          className="bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] hover:from-[#2563EB] hover:to-[#7C3AED]"
        >
          <Download className="h-4 w-4 mr-2" />
          Export Report
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
          <CardHeader className="pb-3">
            <Label className="text-[#A1A1AA]">Report Type</Label>
          </CardHeader>
          <CardContent>
            <Select value={reportType} onValueChange={(value: typeof reportType) => setReportType(value)}>
              <SelectTrigger className="bg-[#0A0A0A] border-[#2A2A2A] text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#1A1A1A] border-[#2A2A2A]">
                <SelectItem value="sales" className="text-white">Sales Report</SelectItem>
                <SelectItem value="inventory" className="text-white">Inventory Report</SelectItem>
                <SelectItem value="financial" className="text-white">Financial Report</SelectItem>
                <SelectItem value="customer" className="text-white">Customer Report</SelectItem>
                <SelectItem value="employee" className="text-white">Employee Report</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
          <CardHeader className="pb-3">
            <Label className="text-[#A1A1AA]">Date Range</Label>
          </CardHeader>
          <CardContent>
            <Select value={dateRange} onValueChange={(value: typeof dateRange) => setDateRange(value)}>
              <SelectTrigger className="bg-[#0A0A0A] border-[#2A2A2A] text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#1A1A1A] border-[#2A2A2A]">
                <SelectItem value="today" className="text-white">Today</SelectItem>
                <SelectItem value="week" className="text-white">Last 7 Days</SelectItem>
                <SelectItem value="month" className="text-white">Last 30 Days</SelectItem>
                <SelectItem value="quarter" className="text-white">Last 90 Days</SelectItem>
                <SelectItem value="year" className="text-white">Last 365 Days</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>
      </div>

      <Tabs value={reportType} onValueChange={(value) => setReportType(value as typeof reportType)} className="w-full">
        <TabsList className="bg-[#1A1A1A] border-[#2A2A2A]">
          <TabsTrigger value="sales">Sales</TabsTrigger>
          <TabsTrigger value="inventory">Inventory</TabsTrigger>
          <TabsTrigger value="financial">Financial</TabsTrigger>
          <TabsTrigger value="customer">Customer</TabsTrigger>
          <TabsTrigger value="employee">Employee</TabsTrigger>
        </TabsList>

        <TabsContent value="sales" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA] flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Total Revenue
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-[#3B82F6]">
                  ${salesReport.totalRevenue.toFixed(2)}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA] flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" />
                  Total Transactions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-white">
                  {salesReport.totalTransactions}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA] flex items-center gap-2">
                  <TrendingUp className="h-4 w-4" />
                  Avg Transaction
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-white">
                  ${salesReport.avgTransaction.toFixed(2)}
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
            <CardHeader>
              <CardTitle className="text-white">Sales by Payment Method</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {Object.entries(salesReport.salesByPayment).map(([method, amount]) => (
                  <div key={method} className="flex items-center justify-between p-3 bg-[#0A0A0A] rounded-lg">
                    <span className="text-white">{method}</span>
                    <span className="text-[#3B82F6] font-semibold">${amount.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
            <CardHeader>
              <CardTitle className="text-white">Top 10 Customers</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-[#2A2A2A]">
                    <TableHead className="text-[#A1A1AA]">Customer</TableHead>
                    <TableHead className="text-[#A1A1AA]">Tier</TableHead>
                    <TableHead className="text-[#A1A1AA]">Total Spent</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {salesReport.topCustomers.map((customer) => (
                    <TableRow key={customer.id} className="border-[#2A2A2A]">
                      <TableCell className="text-white">{customer.name}</TableCell>
                      <TableCell className="text-[#A1A1AA]">{customer.membership_tier}</TableCell>
                      <TableCell className="text-[#3B82F6] font-semibold">
                        ${customer.totalSpent.toFixed(2)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="inventory" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA] flex items-center gap-2">
                  <Package className="h-4 w-4" />
                  Total Products
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-white">
                  {inventoryReport.totalProducts}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA]">Low Stock Items</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-[#F59E0B]">
                  {inventoryReport.lowStockItems.length}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA]">Out of Stock</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-[#EF4444]">
                  {inventoryReport.outOfStockItems.length}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA]">Inventory Value</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-[#3B82F6]">
                  ${inventoryReport.totalInventoryValue.toFixed(2)}
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
            <CardHeader>
              <CardTitle className="text-white">Low Stock Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-[#2A2A2A]">
                    <TableHead className="text-[#A1A1AA]">Product</TableHead>
                    <TableHead className="text-[#A1A1AA]">Current Stock</TableHead>
                    <TableHead className="text-[#A1A1AA]">Reorder Level</TableHead>
                    <TableHead className="text-[#A1A1AA]">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {inventoryReport.lowStockItems.slice(0, 10).map((product) => (
                    <TableRow key={product.id} className="border-[#2A2A2A]">
                      <TableCell className="text-white">{product.name}</TableCell>
                      <TableCell className="text-[#F59E0B] font-semibold">{product.quantity}</TableCell>
                      <TableCell className="text-[#A1A1AA]">{product.reorder_level || 10}</TableCell>
                      <TableCell>
                        <span className="text-xs px-2 py-1 bg-[#F59E0B]/10 text-[#F59E0B] rounded">
                          Low Stock
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="financial" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA]">Income Statement</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center p-2 bg-[#0A0A0A] rounded">
                  <span className="text-white">Total Revenue</span>
                  <span className="text-[#10B981] font-semibold">
                    ${financialReport.totalRevenue.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center p-2 bg-[#0A0A0A] rounded">
                  <span className="text-white">Cost of Goods Sold</span>
                  <span className="text-[#EF4444] font-semibold">
                    ${financialReport.totalCOGS.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center p-2 bg-[#0A0A0A] rounded border-t border-[#2A2A2A]">
                  <span className="text-white font-semibold">Gross Profit</span>
                  <span className="text-[#3B82F6] font-bold">
                    ${financialReport.grossProfit.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center p-2 bg-[#0A0A0A] rounded">
                  <span className="text-white">Operating Expenses</span>
                  <span className="text-[#EF4444] font-semibold">
                    ${financialReport.operatingExpenses.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center p-2 bg-[#0A0A0A] rounded border-t-2 border-[#3B82F6]">
                  <span className="text-white font-bold">Net Profit</span>
                  <span className="text-[#10B981] font-bold text-lg">
                    ${financialReport.netProfit.toFixed(2)}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA]">Profitability Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-white">Gross Margin</span>
                    <span className="text-[#3B82F6] font-bold">
                      {financialReport.grossMargin.toFixed(2)}%
                    </span>
                  </div>
                  <div className="w-full bg-[#0A0A0A] rounded-full h-3">
                    <div
                      className="bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] h-3 rounded-full"
                      style={{ width: `${Math.min(financialReport.grossMargin, 100)}%` }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-white">Net Margin</span>
                    <span className="text-[#10B981] font-bold">
                      {financialReport.netMargin.toFixed(2)}%
                    </span>
                  </div>
                  <div className="w-full bg-[#0A0A0A] rounded-full h-3">
                    <div
                      className="bg-gradient-to-r from-[#10B981] to-[#34D399] h-3 rounded-full"
                      style={{ width: `${Math.min(financialReport.netMargin, 100)}%` }}
                    />
                  </div>
                </div>

                <div className="p-4 bg-[#0A0A0A] rounded-lg border border-[#2A2A2A] mt-4">
                  <p className="text-xs text-[#A1A1AA] mb-2">Financial Health Score</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1">
                      <div className="w-full bg-[#2A2A2A] rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-[#10B981] to-[#3B82F6] h-2 rounded-full"
                          style={{ width: `${Math.min((financialReport.netMargin + financialReport.grossMargin) / 2, 100)}%` }}
                        />
                      </div>
                    </div>
                    <span className="text-white font-bold">
                      {((financialReport.netMargin + financialReport.grossMargin) / 2).toFixed(1)}%
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="customer" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA] flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  Total Customers
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-white">
                  {customerReport.totalCustomers}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA]">Active Customers</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-[#10B981]">
                  {customerReport.activeCustomers}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA]">New Customers</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-[#3B82F6]">
                  {customerReport.newCustomers}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA]">Avg Customer Value</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-[#3B82F6]">
                  ${customerReport.avgCustomerValue.toFixed(2)}
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader>
                <CardTitle className="text-white">Customers by Tier</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {Object.entries(customerReport.customersByTier).map(([tier, count]) => (
                  <div key={tier} className="flex items-center justify-between p-3 bg-[#0A0A0A] rounded-lg">
                    <span className="text-white">{tier}</span>
                    <span className="text-[#3B82F6] font-semibold">{count}</span>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader>
                <CardTitle className="text-white">Customer Retention</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-white">Retention Rate</span>
                      <span className="text-[#10B981] font-bold">
                        {customerReport.retentionRate.toFixed(2)}%
                      </span>
                    </div>
                    <div className="w-full bg-[#0A0A0A] rounded-full h-4">
                      <div
                        className="bg-gradient-to-r from-[#10B981] to-[#34D399] h-4 rounded-full"
                        style={{ width: `${Math.min(customerReport.retentionRate, 100)}%` }}
                      />
                    </div>
                  </div>
                  <p className="text-xs text-[#A1A1AA]">
                    Percentage of customers with repeat purchases
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="employee" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA]">Total Employees</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-white">
                  {employeeReport.totalEmployees}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA]">Active</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-[#10B981]">
                  {employeeReport.activeEmployees}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA]">On Leave</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-[#F59E0B]">
                  {employeeReport.onLeave}
                </p>
              </CardContent>
            </Card>

            <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-[#A1A1AA]">Total Payroll</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-[#3B82F6]">
                  ${employeeReport.totalPayroll.toLocaleString()}
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
            <CardHeader>
              <CardTitle className="text-white">Employees by Department</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {Object.entries(employeeReport.employeesByDepartment).map(([dept, count]) => (
                <div key={dept} className="flex items-center justify-between p-3 bg-[#0A0A0A] rounded-lg">
                  <span className="text-white">{dept}</span>
                  <span className="text-[#3B82F6] font-semibold">{count}</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}