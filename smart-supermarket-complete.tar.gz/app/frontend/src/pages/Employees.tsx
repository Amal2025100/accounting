import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/lib/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { Search, Plus, Edit, UserCheck, Phone, Mail, Calendar, DollarSign, Clock, Award } from 'lucide-react';
import type { Employee, Shift } from '@/types';

export default function Employees() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showDialog, setShowDialog] = useState(false);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [employeeShifts, setEmployeeShifts] = useState<Shift[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    employee_code: '',
    name: '',
    email: '',
    phone: '',
    position: '',
    department: '',
    hire_date: new Date().toISOString().split('T')[0],
    salary: 0,
    status: 'Active' as 'Active' | 'Inactive' | 'On Leave',
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [employeesData, shiftsData] = await Promise.all([
        api.employees.getAll(),
        api.shifts.getAll(),
      ]);
      setEmployees(employeesData);
      setShifts(shiftsData);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load data',
        variant: 'destructive',
      });
    }
  };

  const filteredEmployees = employees.filter(
    (e) =>
      e.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.employee_code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (e.position && e.position.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (e.department && e.department.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleOpenDialog = (employee?: Employee) => {
    if (employee) {
      setEditingEmployee(employee);
      setFormData({
        employee_code: employee.employee_code,
        name: employee.name,
        email: employee.email || '',
        phone: employee.phone || '',
        position: employee.position || '',
        department: employee.department || '',
        hire_date: employee.hire_date ? employee.hire_date.split(' ')[0] : new Date().toISOString().split('T')[0],
        salary: employee.salary || 0,
        status: employee.status,
      });
    } else {
      setEditingEmployee(null);
      setFormData({
        employee_code: `EMP-${Date.now()}`,
        name: '',
        email: '',
        phone: '',
        position: '',
        department: '',
        hire_date: new Date().toISOString().split('T')[0],
        salary: 0,
        status: 'Active',
      });
    }
    setShowDialog(true);
  };

  const handleSubmit = async () => {
    if (!formData.name || !formData.employee_code) {
      toast({
        title: 'Validation Error',
        description: 'Employee code and name are required',
        variant: 'destructive',
      });
      return;
    }

    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      toast({
        title: 'Validation Error',
        description: 'Please enter a valid email address',
        variant: 'destructive',
      });
      return;
    }

    if (formData.salary < 0) {
      toast({
        title: 'Validation Error',
        description: 'Salary must be a positive number',
        variant: 'destructive',
      });
      return;
    }

    setIsLoading(true);
    try {
      const currentDateTime = new Date().toISOString().replace('T', ' ').split('.')[0];

      if (editingEmployee) {
        await api.employees.update(editingEmployee.id, {
          ...formData,
          hire_date: `${formData.hire_date} 00:00:00`,
        });
        toast({
          title: 'Success',
          description: 'Employee updated successfully',
        });
      } else {
        await api.employees.create({
          user_id: user!.id,
          ...formData,
          hire_date: `${formData.hire_date} 00:00:00`,
          created_at: currentDateTime,
        });
        toast({
          title: 'Success',
          description: 'Employee created successfully',
        });
      }

      await loadData();
      setShowDialog(false);
    } catch (error) {
      const detail = (error as { response?: { data?: { detail?: string } }; data?: { detail?: string }; message?: string })?.response?.data?.detail 
                  || (error as { data?: { detail?: string } })?.data?.detail 
                  || (error as Error).message 
                  || 'Failed to save employee';
      toast({
        title: 'Error',
        description: detail,
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleViewDetails = async (employee: Employee) => {
    setSelectedEmployee(employee);
    const empShifts = shifts.filter(s => s.employee_id === employee.id);
    setEmployeeShifts(empShifts);
    setShowDetailsDialog(true);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active':
        return 'bg-[#10B981] text-white';
      case 'On Leave':
        return 'bg-[#F59E0B] text-white';
      case 'Inactive':
        return 'bg-[#EF4444] text-white';
      default:
        return 'bg-[#71717A] text-white';
    }
  };

  const calculateTenure = (hireDate: string) => {
    const hire = new Date(hireDate);
    const now = new Date();
    const months = (now.getFullYear() - hire.getFullYear()) * 12 + (now.getMonth() - hire.getMonth());
    const years = Math.floor(months / 12);
    const remainingMonths = months % 12;
    
    if (years > 0) {
      return `${years}y ${remainingMonths}m`;
    }
    return `${remainingMonths}m`;
  };

  const calculateTotalHours = (empShifts: Shift[]) => {
    return empShifts.reduce((total, shift) => {
      if (shift.clock_in && shift.clock_out) {
        const clockIn = new Date(shift.clock_in);
        const clockOut = new Date(shift.clock_out);
        const hours = (clockOut.getTime() - clockIn.getTime()) / (1000 * 60 * 60);
        return total + hours;
      }
      return total;
    }, 0);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Employee Management</h1>
          <p className="text-[#A1A1AA] mt-1">Manage workforce and track performance</p>
        </div>
        <Button
          onClick={() => handleOpenDialog()}
          className="bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] hover:from-[#2563EB] hover:to-[#7C3AED]"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Employee
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-[#A1A1AA]">Total Employees</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-white">{employees.length}</p>
            <p className="text-xs text-[#10B981] mt-1">
              {employees.filter(e => e.status === 'Active').length} Active
            </p>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-[#A1A1AA]">On Leave</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-white">
              {employees.filter(e => e.status === 'On Leave').length}
            </p>
            <p className="text-xs text-[#A1A1AA] mt-1">Currently away</p>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-[#A1A1AA]">Total Payroll</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-white">
              ${employees.reduce((sum, e) => sum + (e.salary || 0), 0).toLocaleString()}
            </p>
            <p className="text-xs text-[#A1A1AA] mt-1">Monthly</p>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-[#A1A1AA]">Avg Salary</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-white">
              ${employees.length > 0 
                ? Math.round(employees.reduce((sum, e) => sum + (e.salary || 0), 0) / employees.length).toLocaleString()
                : 0}
            </p>
            <p className="text-xs text-[#A1A1AA] mt-1">Per employee</p>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Search className="h-5 w-5 text-[#A1A1AA]" />
            <Input
              placeholder="Search by name, code, position, or department..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-[#0A0A0A] border-[#2A2A2A] text-white"
            />
          </div>
        </CardHeader>
      </Card>

      <Card className="bg-[#1A1A1A] border-[#2A2A2A]">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-[#2A2A2A] hover:bg-[#1A1A1A]">
                <TableHead className="text-[#A1A1AA]">Employee Code</TableHead>
                <TableHead className="text-[#A1A1AA]">Name</TableHead>
                <TableHead className="text-[#A1A1AA]">Position</TableHead>
                <TableHead className="text-[#A1A1AA]">Department</TableHead>
                <TableHead className="text-[#A1A1AA]">Tenure</TableHead>
                <TableHead className="text-[#A1A1AA]">Salary</TableHead>
                <TableHead className="text-[#A1A1AA]">Status</TableHead>
                <TableHead className="text-[#A1A1AA]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredEmployees.map((employee) => (
                <TableRow key={employee.id} className="border-[#2A2A2A] hover:bg-[#0A0A0A]">
                  <TableCell className="font-medium text-white">{employee.employee_code}</TableCell>
                  <TableCell>
                    <div>
                      <p className="text-white font-medium">{employee.name}</p>
                      {employee.email && (
                        <p className="text-xs text-[#A1A1AA]">{employee.email}</p>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-white">{employee.position || 'N/A'}</TableCell>
                  <TableCell className="text-white">{employee.department || 'N/A'}</TableCell>
                  <TableCell className="text-[#A1A1AA]">
                    {employee.hire_date ? calculateTenure(employee.hire_date) : 'N/A'}
                  </TableCell>
                  <TableCell className="text-white font-semibold">
                    ${(employee.salary || 0).toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(employee.status)}>
                      {employee.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewDetails(employee)}
                        className="text-[#3B82F6] hover:text-[#3B82F6] hover:bg-[#3B82F6]/10"
                      >
                        View
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleOpenDialog(employee)}
                        className="text-[#10B981] hover:text-[#10B981] hover:bg-[#10B981]/10"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Create/Edit Employee Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="bg-[#1A1A1A] border-[#2A2A2A] text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingEmployee ? 'Edit Employee' : 'Add New Employee'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Employee Code *</Label>
              <Input
                value={formData.employee_code}
                onChange={(e) => setFormData({ ...formData, employee_code: e.target.value })}
                className="bg-[#0A0A0A] border-[#2A2A2A] text-white"
                disabled={!!editingEmployee}
              />
            </div>
            <div className="space-y-2">
              <Label>Full Name *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-[#0A0A0A] border-[#2A2A2A] text-white"
              />
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="bg-[#0A0A0A] border-[#2A2A2A] text-white"
              />
            </div>
            <div className="space-y-2">
              <Label>Phone</Label>
              <Input
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="bg-[#0A0A0A] border-[#2A2A2A] text-white"
              />
            </div>
            <div className="space-y-2">
              <Label>Position</Label>
              <Input
                value={formData.position}
                onChange={(e) => setFormData({ ...formData, position: e.target.value })}
                className="bg-[#0A0A0A] border-[#2A2A2A] text-white"
              />
            </div>
            <div className="space-y-2">
              <Label>Department</Label>
              <Input
                value={formData.department}
                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                className="bg-[#0A0A0A] border-[#2A2A2A] text-white"
              />
            </div>
            <div className="space-y-2">
              <Label>Hire Date</Label>
              <Input
                type="date"
                value={formData.hire_date}
                onChange={(e) => setFormData({ ...formData, hire_date: e.target.value })}
                className="bg-[#0A0A0A] border-[#2A2A2A] text-white"
              />
            </div>
            <div className="space-y-2">
              <Label>Monthly Salary</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.salary}
                onChange={(e) => setFormData({ ...formData, salary: parseFloat(e.target.value) || 0 })}
                className="bg-[#0A0A0A] border-[#2A2A2A] text-white"
              />
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={formData.status} onValueChange={(value: 'Active' | 'Inactive' | 'On Leave') => setFormData({ ...formData, status: value })}>
                <SelectTrigger className="bg-[#0A0A0A] border-[#2A2A2A] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#1A1A1A] border-[#2A2A2A]">
                  <SelectItem value="Active" className="text-white">Active</SelectItem>
                  <SelectItem value="On Leave" className="text-white">On Leave</SelectItem>
                  <SelectItem value="Inactive" className="text-white">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowDialog(false)}
              className="bg-[#0A0A0A] border-[#2A2A2A] hover:bg-[#2A2A2A]"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={isLoading}
              className="bg-gradient-to-r from-[#3B82F6] to-[#8B5CF6] hover:from-[#2563EB] hover:to-[#7C3AED]"
            >
              {isLoading ? 'Saving...' : editingEmployee ? 'Update' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Employee Details Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="bg-[#1A1A1A] border-[#2A2A2A] text-white max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Employee Details</DialogTitle>
          </DialogHeader>
          {selectedEmployee && (
            <Tabs defaultValue="info" className="w-full">
              <TabsList className="bg-[#0A0A0A] border-[#2A2A2A]">
                <TabsTrigger value="info">Information</TabsTrigger>
                <TabsTrigger value="shifts">Shift History</TabsTrigger>
                <TabsTrigger value="performance">Performance</TabsTrigger>
              </TabsList>

              <TabsContent value="info" className="space-y-4">
                <div className="grid grid-cols-2 gap-4 p-4 bg-[#0A0A0A] rounded-lg">
                  <div>
                    <p className="text-sm text-[#A1A1AA]">Employee Code</p>
                    <p className="font-semibold text-white">{selectedEmployee.employee_code}</p>
                  </div>
                  <div>
                    <p className="text-sm text-[#A1A1AA]">Full Name</p>
                    <p className="font-semibold text-white">{selectedEmployee.name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-[#A1A1AA]">Email</p>
                    <p className="font-semibold text-white">{selectedEmployee.email || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-[#A1A1AA]">Phone</p>
                    <p className="font-semibold text-white">{selectedEmployee.phone || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-[#A1A1AA]">Position</p>
                    <p className="font-semibold text-white">{selectedEmployee.position || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-[#A1A1AA]">Department</p>
                    <p className="font-semibold text-white">{selectedEmployee.department || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-[#A1A1AA]">Hire Date</p>
                    <p className="font-semibold text-white">
                      {selectedEmployee.hire_date ? new Date(selectedEmployee.hire_date).toLocaleDateString() : 'N/A'}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-[#A1A1AA]">Tenure</p>
                    <p className="font-semibold text-white">
                      {selectedEmployee.hire_date ? calculateTenure(selectedEmployee.hire_date) : 'N/A'}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-[#A1A1AA]">Monthly Salary</p>
                    <p className="font-semibold text-[#3B82F6] text-lg">
                      ${(selectedEmployee.salary || 0).toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-[#A1A1AA]">Status</p>
                    <Badge className={getStatusColor(selectedEmployee.status)}>
                      {selectedEmployee.status}
                    </Badge>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="shifts">
                <Table>
                  <TableHeader>
                    <TableRow className="border-[#2A2A2A]">
                      <TableHead className="text-[#A1A1AA]">Date</TableHead>
                      <TableHead className="text-[#A1A1AA]">Clock In</TableHead>
                      <TableHead className="text-[#A1A1AA]">Clock Out</TableHead>
                      <TableHead className="text-[#A1A1AA]">Hours</TableHead>
                      <TableHead className="text-[#A1A1AA]">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {employeeShifts.length > 0 ? (
                      employeeShifts.map((shift) => {
                        const hours = shift.clock_in && shift.clock_out
                          ? ((new Date(shift.clock_out).getTime() - new Date(shift.clock_in).getTime()) / (1000 * 60 * 60)).toFixed(2)
                          : 'N/A';
                        return (
                          <TableRow key={shift.id} className="border-[#2A2A2A]">
                            <TableCell className="text-white">
                              {new Date(shift.shift_date).toLocaleDateString()}
                            </TableCell>
                            <TableCell className="text-[#A1A1AA]">
                              {shift.clock_in ? new Date(shift.clock_in).toLocaleTimeString() : 'N/A'}
                            </TableCell>
                            <TableCell className="text-[#A1A1AA]">
                              {shift.clock_out ? new Date(shift.clock_out).toLocaleTimeString() : 'N/A'}
                            </TableCell>
                            <TableCell className="text-white font-semibold">{hours}</TableCell>
                            <TableCell>
                              <Badge variant={shift.clock_out ? 'default' : 'secondary'}>
                                {shift.clock_out ? 'Completed' : 'In Progress'}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    ) : (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-[#A1A1AA] py-8">
                          No shift history available
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </TabsContent>

              <TabsContent value="performance">
                <div className="grid grid-cols-2 gap-4">
                  <Card className="bg-[#0A0A0A] border-[#2A2A2A]">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm text-[#A1A1AA] flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        Total Shifts
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold text-white">{employeeShifts.length}</p>
                    </CardContent>
                  </Card>

                  <Card className="bg-[#0A0A0A] border-[#2A2A2A]">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm text-[#A1A1AA] flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        Total Hours
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold text-[#3B82F6]">
                        {calculateTotalHours(employeeShifts).toFixed(1)}h
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="bg-[#0A0A0A] border-[#2A2A2A]">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm text-[#A1A1AA] flex items-center gap-2">
                        <Award className="h-4 w-4" />
                        Avg Hours/Shift
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold text-white">
                        {employeeShifts.length > 0
                          ? (calculateTotalHours(employeeShifts) / employeeShifts.length).toFixed(1)
                          : '0.0'}h
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="bg-[#0A0A0A] border-[#2A2A2A]">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm text-[#A1A1AA] flex items-center gap-2">
                        <DollarSign className="h-4 w-4" />
                        Est. Earnings
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-3xl font-bold text-white">
                        ${((selectedEmployee.salary || 0) / 160 * calculateTotalHours(employeeShifts)).toFixed(2)}
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          )}
          <DialogFooter>
            <Button
              onClick={() => setShowDetailsDialog(false)}
              className="bg-[#0A0A0A] border-[#2A2A2A] hover:bg-[#2A2A2A]"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}