# Core package for configuration and shared utilities
